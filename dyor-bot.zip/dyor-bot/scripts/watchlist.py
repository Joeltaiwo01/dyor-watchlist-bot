"""
WATCHLIST STORAGE
This is the bot's memory. Every run:
  1. loads this file
  2. adds newly-discovered, passed-DYOR projects
  3. re-checks everything still 'pending' for a status change
  4. saves it back

The GitHub Actions workflow commits this file back to the repo after
every run, so the bot never forgets what it's tracking between runs.
"""

import json
import os
import config


def load():
    if not os.path.exists(config.WATCHLIST_FILE):
        return {}
    with open(config.WATCHLIST_FILE, "r") as f:
        return json.load(f)


def save(watchlist):
    os.makedirs(os.path.dirname(config.WATCHLIST_FILE), exist_ok=True)
    with open(config.WATCHLIST_FILE, "w") as f:
        json.dump(watchlist, f, indent=2)


def add(watchlist, candidate, vet_result, first_seen):
    watchlist[candidate["id"]] = {
        "name": candidate["name"],
        "source": candidate["source"],
        "status": vet_result["status"],
        "chains": vet_result["chains"],
        "reasons": vet_result["reasons"],
        "first_seen": first_seen,
        "last_checked": first_seen,
        "notified_live": False,
    }
    return watchlist
