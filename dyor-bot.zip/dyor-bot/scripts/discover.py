"""
DISCOVERY
Finds new project candidates from legit, free, no-card-needed sources.

- CoinGecko "recently added" coins  -> projects that got listed
- DefiLlama "raises"                -> projects that got real VC funding
                                        (often BEFORE they've launched a token)

Each candidate is returned as a plain dict so the rest of the bot
doesn't need to know which source it came from.
"""

import requests

COINGECKO_NEW = "https://api.coingecko.com/api/v3/coins/list/new"
DEFILLAMA_RAISES = "https://api.llama.fi/raises"


def get_coingecko_candidates():
    """Recently added coins on CoinGecko. Being listed here already means
    CoinGecko itself has done basic vetting (real contract, real team page)."""
    candidates = []
    try:
        resp = requests.get(COINGECKO_NEW, timeout=20)
        resp.raise_for_status()
        for coin in resp.json():
            candidates.append({
                "source": "coingecko",
                "id": coin.get("id"),
                "name": coin.get("name"),
                "symbol": coin.get("symbol"),
                "activated_at": coin.get("activated_at"),
            })
    except Exception as e:
        print(f"[discover] CoinGecko fetch failed: {e}")
    return candidates


def get_defillama_raise_candidates():
    """Projects that announced real funding rounds. These are often
    pre-launch — exactly the 'mentioned before, hasn't gone live yet'
    category you want tracked."""
    candidates = []
    try:
        resp = requests.get(DEFILLAMA_RAISES, timeout=20)
        resp.raise_for_status()
        data = resp.json().get("raises", [])
        for raise_ in data:
            candidates.append({
                "source": "defillama_raise",
                "id": f"defillama-{raise_.get('name')}".lower().replace(" ", "-"),
                "name": raise_.get("name"),
                "amount_usd": raise_.get("amount"),
                "date": raise_.get("date"),
                "chains": raise_.get("chains", []),
                "investors": raise_.get("leadInvestors", []) + raise_.get("otherInvestors", []),
            })
    except Exception as e:
        print(f"[discover] DefiLlama fetch failed: {e}")
    return candidates


def discover_all():
    candidates = []
    candidates.extend(get_coingecko_candidates())
    candidates.extend(get_defillama_raise_candidates())
    return candidates
