"""
Settings for the DYOR watchlist bot.
Change numbers here later if you want the filter stricter or looser —
you don't need to touch any other file to tune it.
"""

# --- Notifications (ntfy.sh) ---
# Pick a topic name only you would guess — it's not password protected,
# so a hard-to-guess name (letters+numbers) is your "privacy" here.
NTFY_TOPIC = "Jay_dyor_alerts-8x2f"
NTFY_URL = f"https://ntfy.sh/{NTFY_TOPIC}"

# --- DYOR filter thresholds ---
# A project must clear these to make it onto your watchlist at all.
MIN_FUNDING_USD = 0          # 0 = funding not required, just noted if present
REQUIRE_GITHUB_ACTIVITY = False   # True = must have a real GitHub repo to pass
MIN_GITHUB_STARS = 5

# --- Chains we care about most (from your airdrop-farming setup) ---
# Not a hard filter — just used to flag/prioritize matches in the alert text.
PRIORITY_CHAINS = ["ethereum", "base", "binance-smart-chain", "solana", "arbitrum"]

# --- Files ---
WATCHLIST_FILE = "data/watchlist.json"
