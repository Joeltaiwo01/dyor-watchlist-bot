# DYOR Watchlist Bot

Automatically finds real crypto projects (verified via CoinGecko/CoinMarketCap/
DefiLlama/GitHub — not fake tweets), keeps a permanent watchlist of ones that
are still pending launch, and pushes a phone notification the moment a
project you're tracking goes live — including which blockchain it launched on.

Runs every 20 minutes automatically via GitHub Actions. You never have to
open this repo or press anything once it's set up.

## Setup (one-time, ~5 minutes, no card needed)

### 1. Get the ntfy app (for notifications)
- Install **ntfy** from the App Store / Play Store (free)
- Open the app, tap "+", and subscribe to this exact topic name:
  `joel-dyor-alerts-8x2f`
  (You can change this name in `config.py` before setup if you want —
  just make sure the app and the config file match.)
- That's it — any message the bot sends to that topic shows up as a push
  notification on your phone.

### 2. Create a GitHub repo
- Go to github.com, create a new **public** repo (private also works, but
  public keeps GitHub Actions minutes unlimited/free)
- Upload all the files in this folder to that repo, keeping the same
  folder structure (`scripts/`, `.github/workflows/`, `config.py`, `data/`)

### 3. Turn on Actions
- In your repo, go to the "Actions" tab
- GitHub may ask you to confirm you want workflows enabled — click yes
- The bot will now run automatically every 20 minutes, forever, for free

### 4. (Optional) Run it once manually to test
- Go to Actions → "DYOR Watchlist Bot" → "Run workflow" button
- Check your phone — you should get notifications within a minute or two
  if any projects currently pass the filter

## How it works day to day
- You do nothing. It runs itself.
- New legit project found → you get a notification explaining why it passed.
- A project you're already tracking goes live → you get a second notification
  telling you it's live and which chain.
- Everything it's tracking lives in `data/watchlist.json`, which the bot
  updates and saves back to the repo automatically every run.

## Tuning it later
Open `config.py` to adjust:
- `MIN_FUNDING_USD` — raise this if you only want well-funded projects
- `REQUIRE_GITHUB_ACTIVITY` — set `True` to require a real GitHub repo
- `PRIORITY_CHAINS` — chains you care most about
